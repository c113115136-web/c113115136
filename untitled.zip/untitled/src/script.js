function openTab(evt, seriesId) {
    var i, tabcontent, tablinks;

    // 1. 隱藏所有作品
    tabcontent = document.getElementsByClassName("tab-content");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    // 2. 移除所有按鈕的選中顏色
    tablinks = document.getElementsByClassName("tab-btn");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].classList.remove("active");
    }

    // 3. 顯示你點的那一個作品
    var target = document.getElementById(seriesId);
    if (target) {
        target.style.display = "block";
        evt.currentTarget.classList.add("active");
    }
}